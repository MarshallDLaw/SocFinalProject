package com.example.mallmapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class InorbitFoodCourtMenuAdapter extends RecyclerView.Adapter<InorbitFoodCourtMenuAdapter.MyViewHolder> {

    String data11[], data22[];
    int images1[];
    Context context1;

    public InorbitFoodCourtMenuAdapter(Context ct, String s11[], String s22[], int img1[] ){
        context1 = ct;
        data11 = s11;
        data22 = s22;
        images1 = img1;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context1);
        View view = inflater.inflate(R.layout.menu_row, parent, false);
        return new InorbitFoodCourtMenuAdapter.MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        holder.inorbit_brands_txt.setText(data11[position]);
        holder.inorbit_brands_description_txt.setText(data22[position]);
        holder.inorbit_brands_img.setImageResource(images1[position]);
    }

    @Override
    public int getItemCount()  {
        return images1.length;
    }

    public  class MyViewHolder extends RecyclerView.ViewHolder{

        TextView inorbit_brands_txt, inorbit_brands_description_txt;
        ImageView inorbit_brands_img;

            public MyViewHolder(@NonNull View itemView) {
                super(itemView);
                inorbit_brands_txt = itemView.findViewById(R.id.inorbit_brands_txt);
                inorbit_brands_description_txt = itemView.findViewById(R.id.inorbit_brands_description_txt);
                inorbit_brands_img = itemView.findViewById(R.id.inorbit_brands_img);

            }
        }

    }