package com.example.mallmapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

public class InorbitBrandsMenu extends AppCompatActivity {

    RecyclerView inorbitmenurecycleview;

    String s1[], s2[];
    int images [] = {R.drawable.aldo,R.drawable.bigbazaar,R.drawable.caratlane,R.drawable.croma,R.drawable.fila,R.drawable.gametheshop,R.drawable.hamleys,R.drawable.hidesign,R.drawable.hp,R.drawable.hummel,R.drawable.nike,R.drawable.planetsuperheroes,R.drawable.reliancejewels,R.drawable.samsonite,R.drawable.superdry,R.drawable.tanishq,R.drawable.unicorn,R.drawable.vip,R.drawable.vivo};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inorbit_brands_menu);

        inorbitmenurecycleview = findViewById(R.id.inorbitmenurecycleview);

        s1 = getResources().getStringArray(R.array.inorbit_brands);
        s2 = getResources().getStringArray(R.array.inorbit_brands_description);

        InorbitBrandsMenuAdapter inorbitMenuAdapter = new InorbitBrandsMenuAdapter(this, s1, s2, images);
        inorbitmenurecycleview.setAdapter(inorbitMenuAdapter);
        inorbitmenurecycleview.setLayoutManager(new LinearLayoutManager(this));
    }
}
