package com.example.mallmapp;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.content.Intent;
import androidx.fragment.app.Fragment;

public class HomeFragment extends Fragment {
    Button inorbitmenubuttoncode;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view =  inflater.inflate(R.layout.home_fragment, container, false);
        inorbitmenubuttoncode = (Button)view.findViewById(R.id.inoribitmenubutton);
        inorbitmenubuttoncode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getActivity(), InorbitMenu.class));
            }
        });
        return view;
    }
}