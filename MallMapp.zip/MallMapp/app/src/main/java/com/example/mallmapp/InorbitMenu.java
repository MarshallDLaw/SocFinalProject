package com.example.mallmapp;

        import androidx.appcompat.app.AppCompatActivity;
        import androidx.fragment.app.Fragment;
        import androidx.fragment.app.FragmentManager;
        import android.content.Intent;
        import android.os.Bundle;
        import android.view.View;
        import android.widget.Button;

public class InorbitMenu extends AppCompatActivity implements View.OnClickListener{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inorbit_menu);

        Button inoribitatmmenubutton = findViewById(R.id.inoribitatmmenubutton);
        Button inoribitwashroommenubutton = findViewById(R.id.inoribitwashroommenubutton);
        Button inoribitdrinkingwatermenubutton = findViewById(R.id.inoribitdrinkingwatermenubutton);
        Button inoribitfoodcourtmenubutton = findViewById(R.id.inoribitfoodcourtmenubutton);
        Button inoribitbrandsmenubutton = findViewById(R.id.inoribitbrandsmenubutton);
        Button inoribitcinemamenubutton = findViewById(R.id.inoribitcinemamenubutton);

        inoribitatmmenubutton.setOnClickListener(this);
        inoribitwashroommenubutton.setOnClickListener(this);
        inoribitdrinkingwatermenubutton.setOnClickListener(this);
        inoribitfoodcourtmenubutton.setOnClickListener(this);
        inoribitbrandsmenubutton.setOnClickListener(this);
        inoribitcinemamenubutton.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.inoribitatmmenubutton:
                openInorbitAtmMenu();
                break;
            case R.id.inoribitwashroommenubutton:
                openInorbitWashroomMenu();
                break;
            case R.id.inoribitdrinkingwatermenubutton:
                openInorbitDrinkingWaterMenu();
                break;
            case R.id.inoribitfoodcourtmenubutton:
                openInorbitFoodCourtMenu();
                break;
            case R.id.inoribitbrandsmenubutton:
                openInorbitBrandsMenu();
                break;
            case R.id.inoribitcinemamenubutton:
                openInorbitCinemaMenu();
                break;
        }
    }
    public void openInorbitAtmMenu() {
        Intent intent = new Intent(this, InorbitAtmMenu.class);
        startActivity(intent);
    }
    public void openInorbitWashroomMenu() {
        Intent intent = new Intent(this, InorbitWashroomMenu.class);
        startActivity(intent);
    }
    public void openInorbitDrinkingWaterMenu() {
        Intent intent = new Intent(this, InorbitFountainMenu.class);
        startActivity(intent);
    }
    public void openInorbitFoodCourtMenu() {
        Intent intent = new Intent(this, InorbitFoodCourtMenu.class);
        startActivity(intent);
    }
    public void openInorbitBrandsMenu() {
        Intent intent = new Intent(this, InorbitBrandsMenu.class);
        startActivity(intent);
    }
    public void openInorbitCinemaMenu() {
        Intent intent = new Intent(this, InorbitCinemaMenu.class);
        startActivity(intent);
    }
}