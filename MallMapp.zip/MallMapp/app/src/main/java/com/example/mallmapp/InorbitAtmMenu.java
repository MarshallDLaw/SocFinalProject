package com.example.mallmapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class InorbitAtmMenu extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inorbit_atm_menu);
    }
}
