package com.example.mallmapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class InorbitCinemaMenu extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inorbit_cinema_menu);
    }
}
