package com.example.mallmapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

public class InorbitFoodCourtMenu extends AppCompatActivity {

    RecyclerView inorbitfoodrecycleview;

    String s11[], s22[];
    int images2[]={R.drawable.baskinrobbins, R.drawable.hoppipola, R.drawable.kebabkorner, R.drawable.keventers, R.drawable.madoverdonuts, R.drawable.subway, R.drawable.wowmomo, R.drawable.yoghurtstudio};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inorbit_food_court_menu);

        inorbitfoodrecycleview = findViewById(R.id.inorbitfoodrecycleview);

        s11 = getResources().getStringArray(R.array.inorbit_food);
        s22 = getResources().getStringArray(R.array.inorbit_food_description);

        InorbitFoodCourtMenuAdapter inorbitFoodCourtMenuAdapter = new InorbitFoodCourtMenuAdapter(this, s11, s22, images2);
        inorbitfoodrecycleview.setAdapter(inorbitFoodCourtMenuAdapter);
        inorbitfoodrecycleview.setLayoutManager(new LinearLayoutManager(this));
    }
}
